package test;

import java.io.FileInputStream;
import java.io.IOException;
import static java.lang.Double.parseDouble;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import modele.Gare;

public class test_gare {

    public static void main(String args[]) {
        final EntityManagerFactory emf = Persistence.createEntityManagerFactory("Voyage2IPU");
        final EntityManager em = emf.createEntityManager();
        try {
            final EntityTransaction et = em.getTransaction();
            try {
                final String SEPARATEUR = "\t";
                
                // Le fichier d'entrée
                FileInputStream file = new FileInputStream("C:\\Users\\giorg\\Documents\\NetBeansProjects\\gares.txt");//RENOMMER LE CHEMIN CAR C PAS LE BON
                Scanner scanner = new Scanner(file);

                //renvoie true s'il y a une autre ligne à lire
                scanner.nextLine();
                while (scanner.hasNextLine()) {

                    String mots[] = scanner.nextLine().split(SEPARATEUR);
                    et.begin();
                    Gare g = new Gare( mots[0], mots[1],  Integer.parseInt(mots[2]),  parseDouble(mots[3]),  parseDouble(mots[4]));
                    System.out.println(g.toString());
                    em.persist(g);
                    et.commit();
                }
                scanner.close();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception ex) {
                et.rollback();
            }
        } finally {
            if (em != null && em.isOpen()) {
                em.close();
            }
            if (emf != null && emf.isOpen()) {
                emf.close();
            }
        }
    }
}