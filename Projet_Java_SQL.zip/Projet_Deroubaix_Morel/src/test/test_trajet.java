package test;

import java.io.FileInputStream;
import java.io.IOException;
import static java.lang.Double.parseDouble;
import java.sql.Date;
import java.sql.Time;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import modele.Gare;
import modele.Train;
import modele.Troncon;

public class test_trajet {

    private static Date parseDate(String h) {
        String hSplitted[] = h.split("/");
        return new Date(Integer.parseInt(hSplitted[2]), Integer.parseInt(hSplitted[1]), Integer.parseInt(hSplitted[0]));
    }

    private static Time parseTime(String h) {
        String hSplitted[] = h.split(":");
        return new Time(Integer.parseInt(hSplitted[0]), Integer.parseInt(hSplitted[1]),0);
    }

    private static Gare GetGare(Set<Gare> gares, String nom) {
        for (Gare i : gares) {
            if (i.getNom().equals(nom)) {
                return i;
            }
        }
        return null;
    }

    public static void main(String args[]) {
        final EntityManagerFactory emf = Persistence.createEntityManagerFactory("Voyage2IPU");
        final EntityManager em = emf.createEntityManager();
        try {
            final EntityTransaction et = em.getTransaction();
            try {

                final String SEPARATEUR = "\t";
                Set<Gare> gares = new HashSet<>();

                // Le fichier d'entrée
                FileInputStream file = new FileInputStream("C:\\Users\\giorg\\Documents\\NetBeansProjects\\gares.txt");
                Scanner scanner = new Scanner(file);

                //renvoie true s'il y a une autre ligne à lire
                scanner.nextLine();
                et.begin();
                while (scanner.hasNextLine()) {

                    String mots[] = scanner.nextLine().split(SEPARATEUR);
                    Gare g = new Gare(mots[0], mots[1], Integer.parseInt(mots[2]), parseDouble(mots[3]), parseDouble(mots[4]));
                    gares.add(g);
                    em.persist(g);

                }
                //et.commit();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                //  Partie Troncons
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                // Le fichier d'entrée
                FileInputStream file2 = new FileInputStream("C:\\Users\\giorg\\Documents\\NetBeansProjects\\trajets.txt");
                Scanner scanner2 = new Scanner(file2);

                //renvoie true s'il y a une autre ligne à lire
                while (scanner2.hasNextLine()) {
                    if (scanner2.nextLine().contains("DebutTrajet")) {

                        String mots[] = scanner2.nextLine().split(SEPARATEUR);

                        //Affectation var
                        Date date = parseDate(mots[0]); //date du trajet
                        int num = Integer.parseInt(mots[1]);//n° du train

                        String gareD = mots[2];
                        Time heureD = parseTime(mots[3]);

                        String gareArr = mots[4];
                        Time heureArr = parseTime(mots[5]);

                        int nbTr = Integer.parseInt(mots[6]);

                        //22/11/2022	0006	lille europe	11:56	paris nord	12:55	1
                        Train tra = new Train(date, num);
                        if (nbTr == 1) {

                            String motsTr[] = scanner2.nextLine().split(SEPARATEUR);
                            int prix = Integer.parseInt(motsTr[1]);

                            Troncon tro = new Troncon(prix, heureArr, heureD);
                            tro.addTrain(tra);

                            //et.begin();
                            em.persist(tra);
                            em.persist(tro);
                            //et.commit();

                            Gare g = GetGare(gares, gareArr);
                            tro.setGareArrivee(g);
                            g = GetGare(gares, gareD);
                            tro.setGareDepart(g);

                        } else {
                            //et.begin();
                            for (int i = 0; i < nbTr - 1; i++) {
                                String motsTr[] = scanner2.nextLine().split(SEPARATEUR);

                                int prix = Integer.parseInt(motsTr[3]);

                                String gareA = motsTr[0];
                                Time heureA = parseTime(motsTr[1]);

                                Troncon tro = new Troncon(prix, heureA, heureD);

                                Gare g = GetGare(gares, gareA);
                                tro.setGareArrivee(g);

                                g = GetGare(gares, gareD);
                                tro.setGareDepart(g);

                                tro.addTrain(tra);
                                em.persist(tro);

                                gareD = gareA;
                                heureD = parseTime(motsTr[2]);

                            }
                            String motsTr[] = scanner2.nextLine().split(SEPARATEUR);
                            int prix = Integer.parseInt(motsTr[1]);

                            Troncon tro = new Troncon(prix, heureArr, heureD);
                            tro.addTrain(tra);

                            Gare g = GetGare(gares, gareArr);
                            tro.setGareArrivee(g);

                            g = GetGare(gares, gareD);
                            tro.setGareDepart(g);

                            em.persist(tro);
                            em.persist(tra);
                            //et.commit();
                        }
                        //et.commit();
                    }
                }
                et.commit();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception ex) {
                //et.rollback();
                ex.printStackTrace();
            }
        } finally {
            if (em != null && em.isOpen()) {
                em.close();
            }
            if (emf != null && emf.isOpen()) {
                emf.close();
            }
        }
    }
}
