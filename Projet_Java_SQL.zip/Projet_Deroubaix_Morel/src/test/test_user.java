package test;

import java.io.FileInputStream;
import java.io.IOException;
import static java.lang.Double.parseDouble;
import java.time.LocalDate;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import modele.Utilisateur;

public class test_user {

    public static void main(String args[]) {
        final EntityManagerFactory emf = Persistence.createEntityManagerFactory("Voyage2IPU");
        final EntityManager em = emf.createEntityManager();
        try {
            final EntityTransaction et = em.getTransaction();
            try {
          
                    et.begin();
                    Utilisateur u = new Utilisateur("login", "email", "passe", "nom", "prenom", LocalDate.parse("2023-01-14"), false);
                    
                    System.out.println(u.toString());
                    em.persist(u);
                    et.commit();
                                
            }  catch (Exception ex) {
                et.rollback();
            }
        } finally {
            if (em != null && em.isOpen()) {
                em.close();
            }
            if (emf != null && emf.isOpen()) {
                emf.close();
            }
        }
    }
}