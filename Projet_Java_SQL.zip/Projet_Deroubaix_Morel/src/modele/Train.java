package modele;

import java.io.Serializable;
import java.sql.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 *
 * @author 6leam
 */
@Entity
@Table(uniqueConstraints = {
    @UniqueConstraint(columnNames = {"NUMTRAIN"})})
public class Train implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable = false)
    private long id;

    @Column(nullable = false)
    //@Temporal(javax.persistence.TemporalType.DATE)
    private Date dateTrajet;

    @Column(nullable = false)
    private int numTrain;

    // Lien avec objet troncon : Un train = plusieurs troncon mais un troncon = un train
    @OneToMany(mappedBy = "train")
    private Set<Troncon> troncons;

    //Consctructeur par défault
    public Train() {
        this.dateTrajet = new Date(0,0,0);
        this.numTrain = 0000;
        this.troncons = new HashSet<>();
    }

    //Constructeur par données
    public Train(Date dateTrajet, int numTrain) {
        this.dateTrajet = dateTrajet;
        this.numTrain = numTrain;
        this.troncons = new HashSet<>();

    }

    /*--------------FONCTIONS DE LIAISONS TRAIN-TRONCON------------------------------------------------------------------------------------------*/
    //set troncon
    public void setTronconTrain(Troncon troncon) {
        if (troncon == null) {
            return;
        }
    }

    void addTroncon(Troncon t) {
        if (t != null) {
            if (!this.troncons.contains(t)) {
                //System.out.println(t);
                this.troncons.add(t);
            }
        }
    }

    //supprimer le troncon 
    public boolean suppTronconTrain(Troncon t) {
        if (t == null) {
            return false;
        }
        return this.troncons.equals(t);
    }

    //get troncon AVEC UN CAST TRONCON
    public Troncon getTronconTrain() {
        return (Troncon) this.troncons;
    }

    boolean remove(Train t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String toString() {
        return "Train{" + "id=" + id + ", dateTrajet=" + dateTrajet + ", numTrain=" + numTrain + ", troncons=" + troncons + '}';
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 43 * hash + this.numTrain;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Train other = (Train) obj;
        if (this.numTrain != other.numTrain) {
            return false;
        }
        return true;
    }
}

/*------------------------------------------------------------------------------------------------------------------------------------------*/