/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author 6leam
 */
public class Requete {

    private Connection conn;
    private static Requete instance; 

    public Requete(){
        
    }
    
    public Utilisateur checkUtilisateur(String login, String mdp) {
        
        final EntityManagerFactory emf = Persistence.createEntityManagerFactory("Voyage2IPU");
        final EntityManager em = emf.createEntityManager();
        
        final String strQuery = "SELECT u from Utilisateur u "
                                + "WHERE u.login = :login "
                                + "AND u.passe = :passe";
        EntityTransaction transaction = em.getTransaction();
        transaction.begin();
        
        Query query = em.createQuery(strQuery);
        query.setParameter("login",login);
        query.setParameter("passe",mdp);

        if (query.getResultList().isEmpty()) return null;
        else return (Utilisateur) query.getSingleResult();
    }
    
 
    
    public static Requete getInstance() throws ClassNotFoundException, SQLException{
        if (instance == null){
            instance=new Requete();
        }
        return instance; 
    }
}
