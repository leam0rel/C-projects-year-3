package modele;

import java.io.Serializable;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

/**
 *
 * @author 6leam
 */
@Entity
public class Trajet implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    //@Temporal(javax.persistence.TemporalType.TIME)
    private LocalTime depart;
    //@Temporal(javax.persistence.TemporalType.TIME)
    private LocalTime arrivee;

    private double prix;

    // Lien avec l'objet troncon
    @ManyToMany(cascade = {CascadeType.ALL})
    @JoinTable(name = "TRAJET_TRONCON")
    private List<Troncon> listeTroncons;

    // Lien avec objet user : 
    @ManyToOne(cascade = {CascadeType.PERSIST})
    @JoinColumn(name = "USER_TRAJET")
    private Utilisateur passager;

    //Constructeur par défault
    public Trajet() {
        this.depart = LocalTime.now();
        this.arrivee = LocalTime.now();
        this.prix = 0;
        this.listeTroncons = new ArrayList<>();
    }

    //Constructeur par données
    public Trajet(LocalTime depart, LocalTime arrivee, double prix, List<Troncon> listeTroncons) {
        this.depart = depart;
        this.arrivee = arrivee;
        this.prix = prix;
        this.listeTroncons = listeTroncons;
    }
    
    
     /*-------------------------------------------------LIAISONS TRONCON-TRAJET-------------------------------------------------------------------------------*/
    
    //vérifier si le troncon appartient au trajet
    public boolean tronconDansTrajet(Troncon troncon) {
        return this.listeTroncons.contains(troncon);
    }

    //set troncon
    public void setTroncon(Troncon troncon) {
        if (troncon == null) {
            return;
        }
        if (this.listeTroncons != null) {
            //this.listeTroncons.suppTrajetTroncon(this);
        }
        this.listeTroncons = (List<Troncon>) troncon; //CAST POUR LISTE
    }
    
    
    //add troncon
    public boolean addTroncon(Troncon troncon){
        if(troncon == null) return false;
        if(this.listeTroncons.equals(troncon)) {
            troncon.setTrajetTroncon(this);
            return true;
        }
        return false;
    }
    
    
    //supprime troncon
    public boolean suppTrajetTroncon(Troncon troncon) {
        if (troncon == null) {
            return false;
        }
        if (!this.equals(troncon.getTrajetTroncon())) {
            return this.listeTroncons.equals(troncon);
        }
        return false;
    }

}
