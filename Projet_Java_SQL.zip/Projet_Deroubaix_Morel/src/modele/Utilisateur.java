package modele;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author 6leam
 */
@Entity
public class Utilisateur implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique = true, nullable = false)
    private String login;
    //@Column(unique = true, nullable = false)
    private String mail;
    @Column(nullable = false)
    private String passe;
    private String nom;
    private String prenom;
    //@Temporal(javax.persistence.TemporalType.DATE)
    private LocalDate naissance;
    private boolean admin;

 

    //Lien avec objet Trajet Un trajet = un user, mais un user = plusieurs trajets 
    @OneToMany(mappedBy = "passager")
    private Set<Trajet> listeTrajets;

    //Constructeur par défault
    public Utilisateur() {
        this.login = "login";
        this.mail = "user@email.com";
        this.passe = "motdepasse";
        this.nom = "nom";
        this.prenom = "prenom";
        this.naissance = LocalDate.now();
        this.admin = false;
        this.listeTrajets = new HashSet<>();
   
        
    }
    

    //Constructeur par données
    public Utilisateur(String login, String mail, String passe, String nom, String prenom, LocalDate naissance, boolean admin){
        this.login = login;
        this.mail = mail;
        this.passe = passe;
        this.nom = nom;
        this.prenom = prenom;
        this.naissance = naissance;
        this.admin = admin;
        
    }

    public Utilisateur(String login, String passe) {
        this.login = login;
        this.passe = passe;

        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public boolean isAdmin() {
        return this.admin;
    }

    
    
    

    public static void main(String args[]) {
        new Utilisateur();
    }
    
}


