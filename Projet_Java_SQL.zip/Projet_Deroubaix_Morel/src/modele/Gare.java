package modele;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 *
 * @author 6leam
 */
@Entity
public class Gare implements Serializable {

    @Id
    @Column(nullable = false)
    private String nom;
    private String ville;
    private int codePostal;
    private double lat;
    private double lon;

    //Lien avec object troncon : Un trajet peut avoir plusieurs gares et une gare peut correspondre à plusieurs trajets 
    @OneToMany(mappedBy = "gareDepart")
    private Set<Troncon> tronconDepart;

    @OneToMany(mappedBy = "gareArrivee")
    private Set<Troncon> tronconArrivee;

    //Constructeur par défault 
    public Gare() {
        this.nom = "name";
        this.ville = "city";
        this.codePostal = 123456789;
        this.lat = 000000;
        this.lon = 111111;

    }

    //Constructeur par données
    public Gare(String nom, String ville, int codePostal, double lat, double lon) {
        this.nom = nom;
        this.ville = ville;
        this.codePostal = codePostal;
        this.lat = lat;
        this.lon = lon;
    }
    
        public String getNom() {
        return nom;
    }
        
    /*--------------FONCTIONS DE LIAISONS TRONCON-GARE------------------------------------------------------------------------------------------------------*/
    //set troncon départ
    public void setTronconDepart(Troncon tronconDepart) {
        if (tronconDepart == null) {
            return;

        }
    }
    
    //set troncon arrivee
    public void setTronconArrivee(Troncon tronconArrivee) {
        if (tronconArrivee == null) {
            return;

        }
    }

    //supprimer le troncon depart
    public boolean suppTronconDepart(Troncon t) {
        if (t == null) {
            return false;
        }
        return this.tronconDepart.equals(t);
    }

    //supprimer le troncon arrivée
    public boolean suppTronconArrivee(Troncon t) {
        if (t == null) {
            return false;
        }
        return this.tronconArrivee.equals(t);
    }
    
    //get troncon depart AVEC UN CAST TRONCON
    public Troncon getTronconDepart() {
        return (Troncon) this.tronconDepart;
    }
    
    //get troncon arrivee
    public Troncon getTronconArrivee() {
        return (Troncon) this.tronconArrivee;
    }
    
    //VOIR REMOVE PASKE PAS SURE
    
    /*------------------------------------------------------------------------------------------------------------------------------------------*/
        @Override
    public String toString() {
        return "Gare{" + "nom=" + nom + ", ville=" + ville + ", codePostal=" + codePostal + ", lat=" + lat + ", lon=" + lon + ", tronconDepart=" + tronconDepart + ", tronconArrivee=" + tronconArrivee + '}';
    }
    
}

