package modele;

import java.io.Serializable;
import java.sql.Time;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

/**
 *
 * @author 6leam
 */
@Entity
public class Troncon implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable = false)
    private long idTroncon;

    @Column(nullable = false)
    private int prix;
    @Column(nullable = false)
    private Time heureArrivee;
    @Column(nullable = false)
    private Time heureDepart;

    // Lien avec objet gare : 
    @ManyToOne(cascade = {CascadeType.PERSIST})
    @JoinColumn(name = "GARE_D")
    private Gare gareDepart;

    @ManyToOne(cascade = {CascadeType.PERSIST})
    @JoinColumn(name = "GARE_A")
    private Gare gareArrivee;

    // Lien avec object train
    @ManyToOne(cascade = {CascadeType.PERSIST})
    @JoinColumn(name = "TRAIN")
    private Train train;

    // Lien avec l'objet trajet
    @ManyToMany(mappedBy = "listeTroncons")
    private Set<Trajet> listeTrajets;

    //Constructeur par default
    public Troncon() {
        this.prix = 0;
        this.heureArrivee = new Time(0,0,0);
        this.heureDepart = new Time(0,0,0);
        this.listeTrajets = new HashSet<>();
    }

    //Constructeur par données
    public Troncon(int prix, Time heureArrivee, Time heureDepart) {
        this.prix = prix;
        this.heureArrivee = heureArrivee;
        this.heureDepart = heureDepart;
    }

    /*-------------- LIAISONS TRONCON-GARE------------------------------------------------------------------------------------------------------*/
    
   
    //vérifier si la gare de départ appartient au troncon
    public boolean gareDepartDansTroncon(Gare g) {
        return this.gareDepart.equals(g);
    }

    //vérifier si la gare d'arrivée appartient au troncon
    public boolean gareArriveeDansTroncon(Gare g) {
        return this.gareArrivee.equals(g);
    }

    //set gare départ
    public void setGareDepart(Gare gareD) {
        if (gareD == null) {
            return;
        }
        if (this.gareDepart != null) {
            this.gareDepart.suppTronconDepart(this);
        }
        this.gareDepart = gareD;
    }

    //set gare arrivée
    public void setGareArrivee(Gare gareA) {
        if (gareA == null) {
            return;
        }
        if (this.gareArrivee != null) {
            this.gareArrivee.suppTronconArrivee(this);
        }
        this.gareArrivee = gareA;
    }

    //add gare départ
    public boolean addGareDepart(Gare gareD) {
        if (gareD == null) {
            return false;
        }
        if (this.gareDepart.equals(gareD)) {
            gareD.setTronconDepart(this);
            return true;
        }
        return false;
    }

    //add gare arrivee
    public boolean addGareArrivee(Gare gareA) {
        if (gareA == null) {
            return false;
        }
        if (this.gareArrivee.equals(gareA)) {
            gareA.setTronconArrivee(this);
            return true;
        }
        return false;
    }

    //PROBLEME REMOVE
    //supprime gare depart
    public boolean suppGareDepart(Gare g) {
        if (g == null) {
            return false;
        }
        if (!this.equals(g.getTronconDepart())) {
            return this.gareDepart.equals(g);
        }
        return false;
    }

    //supprime gare arrivee
    public boolean suppGareArrivee(Gare g) {
        if (g == null) {
            return false;
        }
        if (!this.equals(g.getTronconArrivee())) {
            return this.gareArrivee.equals(g);
        }
        return false;
    }

    
 /*-------------------------------------------------LIAISONS TRONCON-TRAIN-------------------------------------------------------------------------------*/
    
    //vérifier si le train appartient au troncon
    
    public boolean addTrain(Train t){
        if (t == null) return false;
        if (this.train == t) return true;
        this.train = t;
        t.addTroncon(this);
        return true;
    }

    /*-------------------------------------------------LIAISONS TRONCON-TRAJET-------------------------------------------------------------------------------*/
    
    
    //set trajet
    public void setTrajetTroncon(Trajet trajet) {
        if (listeTrajets == null) {
            return;

        }
    }

   
    public boolean suppTrajetTroncon(Trajet trajet) {
        if (trajet == null) {
            return false;
        }
        return this.listeTrajets.equals(trajet);
    }
    
    //get troncon AVEC UN CAST TRONCON
    public Troncon getTrajetTroncon() {
        return (Troncon) this.listeTrajets;
    }

    @Override
    public String toString() {
        return "Troncon{" + "idTroncon=" + idTroncon + ", prix=" + prix + ", heureArrivee=" + heureArrivee + ", heureDepart=" + heureDepart + ", gareDepart=" + gareDepart + ", gareArrivee=" + gareArrivee + ", train=" + train + ", listeTrajets=" + listeTrajets + '}';
    }

    
   

}